Thank you for using JScharts (www.jscharts.com)
Please read the following note before starting


JSCharts Free
JS Charts is available free only for non-commercial purpose. 
For commercial use, get the full license from www.jscharts.com. 


License Note
This license does NOT allow you to distribute, resell or embed/enclose JS Charts into another distribution pack/application which outputs similar content that can be used by third parties. 
To get the source codes, special customizations licenses please contact our sales department at sales [at] jumpeyecomponents.com
JScharts by JumpeyeComponents, Smartketer LLC is licensed under a Creative Commons Attribution-Noncommercial-No Derivative Works 3.0 Unported License.
Based on a work at www.jscharts.com. 


Support Note
No support is included within the JSCharts free component, however we encourage you to use JSCharts forum for any issues you encounter.


Start using the JSCharts Note
For details, please read the Jscharts.pdf manual.


For more details please visit our website www.jscharts.com